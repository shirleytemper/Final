const sketchContainer = document.getElementById('sketch-container');

let figures = [];
const numRows = 4;
const numCols = 5;

function setup() {
  const canvas = createCanvas(900, 500);
  canvas.parent('sketch-container');


  const spacingX = width / (numCols - 1);
  const spacingY = height / (numRows - 1);


  for (let row = 1; row <= numRows; row++) {
    for (let col = 1; col <= numCols; col++) {
      const x = col * spacingX;
      const y = row * spacingY;
      const fadeDuration = random(60, 300);
      figures.push(new CartoonFigure(x, y, fadeDuration));
    }
  }
}

function draw() {
  background(40, 99, 107);

  
  for (let i = figures.length - 1; i >= 0; i--) {
    figures[i].update();
    figures[i].display();

    
    if (figures[i].alpha <= 0) {
      figures.splice(i, 1);
    }
  }
  
  
  if (figures.length === 0) {
    createFigures(); 
  }
  
}

function createFigures() {
  figures = []; 

  
  const spacingX = width / (numCols + 1);
  const spacingY = height / (numRows + 1);

  
  for (let row = 1; row <= numRows; row++) {
    for (let col = 1; col <= numCols; col++) {
      const x = col * spacingX;
      const y = row * spacingY;
      const fadeDuration = random(60, 300); 
      figures.push(new CartoonFigure(x, y, fadeDuration));
    }
  }
}  


class CartoonFigure {
  constructor(x, y, fadeDuration) {
    this.x = x;
    this.y = y;
    this.alpha = 255; 
    this.fadeDuration = fadeDuration; 
  }

  update() {
    
    this.alpha -= 255 / this.fadeDuration;
  }

  display() {
    stroke(0, this.alpha);
    fill(115, 49, 37, this.alpha);
    ellipse(this.x, this.y - 30, 30, 30);
    rect(this.x - 15, this.y - 10, 30, 40, 10);
  }
}
