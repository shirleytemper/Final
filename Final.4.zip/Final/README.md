# Final
 Final project for VMS 740

Credits:
Js inspo: katalexandrite@github HIDE GIF: https://github.com/kalexandrite/js_startcoding/blob/main/jsscripts/hidegif.js
Carousel: Bootstrap from W3

Image sources:
1. Harvard University (neuron gif from giphy.com)
2. Adrian Moser Photography
3. EMOTIV LLC
4. Neuralink.com
5. & 6. https://www.nature.com/articles/s41593-022-01046-0
7. UNESCO.com

Content:
Most of this content came from Victoria Wilson Master's thesis: "See You Never: Exclusion in Electroencephalography" and the paper published in Nature linked above (5.)
